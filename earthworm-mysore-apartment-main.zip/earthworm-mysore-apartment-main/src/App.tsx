import { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">My Google AI Studio App</h1>
        
        <div className="bg-indigo-50 rounded-lg p-6 mb-6">
          <p className="text-gray-600 mb-4">Welcome to your React application powered by Vite and Tailwind CSS.</p>
          <div className="flex items-center justify-center">
            <button
              onClick={() => setCount(count + 1)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-6 rounded-lg transition duration-200"
            >
              Count: {count}
            </button>
          </div>
        </div>
        
        <div className="text-sm text-gray-500 text-center">
          <p>Edit <code className="bg-gray-100 px-2 py-1 rounded">src/App.tsx</code> to get started</p>
        </div>
      </div>
    </div>
  );
}

export default App;
