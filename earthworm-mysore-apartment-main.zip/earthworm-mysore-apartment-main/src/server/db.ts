/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import { Database as DatabaseType } from '../types';

const DB_FILE = 'rwa_db.json';

const defaultDatabase: DatabaseType = {
  admins: [
    {
      id: 'adm_001',
      name: 'Admin User',
      email: 'admin@mysoresambhramrwa.in',
      username: 'admin',
      password: 'admin123',
      status: 'active',
      createdAt: new Date().toISOString()
    }
  ],
  residents: [],
  notices: [],
  meetings: [],
  expenses: [],
  payments: [],
  dues: [],
  finances: [],
  links: [],
  feedbacks: [],
  settings: {
    associationName: 'Mysore Sambhram RWA',
    logoUrl: '',
    contactEmail: 'contact@mysoresambhramrwa.in',
    paymentQR: '',
    bankDetails: {
      bankName: '',
      accountNo: '',
      ifscCode: '',
      holderName: ''
    }
  }
};

let db: DatabaseType | null = null;

export class Database {
  static load(): DatabaseType {
    try {
      if (fs.existsSync(DB_FILE)) {
        const data = fs.readFileSync(DB_FILE, 'utf-8');
        db = JSON.parse(data);
        return db;
      }
    } catch (error) {
      console.error('Error loading database:', error);
    }
    db = JSON.parse(JSON.stringify(defaultDatabase));
    return db;
  }

  static save(): void {
    try {
      if (!db) db = this.load();
      fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
    } catch (error) {
      console.error('Error saving database:', error);
    }
  }

  static getAdmins() {
    if (!db) this.load();
    return db!.admins;
  }

  static getResidents() {
    if (!db) this.load();
    return db!.residents;
  }

  static getNotices() {
    if (!db) this.load();
    return db!.notices;
  }

  static getMeetings() {
    if (!db) this.load();
    return db!.meetings;
  }

  static getExpenses() {
    if (!db) this.load();
    return db!.expenses;
  }

  static getPayments() {
    if (!db) this.load();
    return db!.payments;
  }

  static getDues() {
    if (!db) this.load();
    return db!.dues;
  }

  static getFinances() {
    if (!db) this.load();
    return db!.finances;
  }

  static getLinks() {
    if (!db) this.load();
    return db!.links;
  }

  static getFeedbacks() {
    if (!db) this.load();
    return db!.feedbacks;
  }

  static getSettings() {
    if (!db) this.load();
    return db!.settings;
  }

  static updateSettings(updates: Partial<typeof defaultDatabase.settings>) {
    if (!db) this.load();
    db!.settings = { ...db!.settings, ...updates };
    this.save();
    return db!.settings;
  }
}
