/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SessionUser {
  id: string;
  role: 'admin' | 'resident';
  name: string;
  email?: string;
  phone?: string;
  flatNo?: string;
  block?: string;
}

export interface Admin {
  id: string;
  name: string;
  email: string;
  username: string;
  password: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Resident {
  id: string;
  name: string;
  phone: string;
  password: string;
  flatNo: string;
  block: string;
  role: 'owner' | 'tenant';
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
  author: string;
}

export interface Meeting {
  id: string;
  title: string;
  date: string;
  location: string;
  agenda: string;
  minutes: string;
  attachmentName?: string;
  attachmentData?: string; // base64
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  date: string;
  category: string;
  paidTo: string;
  attachmentName?: string;
  attachmentData?: string; // base64
}

export interface MaintenancePayment {
  id: string;
  residentId: string;
  residentName: string;
  flatNo: string;
  block: string;
  month: string;
  amount: number;
  dueDate: string;
  status: 'pending' | 'paid';
  txnId?: string;
  paymentNotes?: string;
  paidAt?: string;
}

export interface MaintenanceDue {
  id: string;
  month: string;
  amount: number;
  dueDate: string;
}

export interface FinanceSummary {
  id: string;
  month: string;
  openingBalance: number;
  totalCollection: number;
  totalExpenses: number;
  closingBalance: number;
  reportName?: string;
  reportData?: string; // base64
}

export interface UsefulLink {
  id: string;
  title: string;
  url: string;
  category: string;
}

export interface Feedback {
  id: string;
  residentId: string;
  residentName: string;
  flatNo: string;
  category: string;
  message: string;
  imageData?: string; // base64
  date: string;
  status: 'open' | 'resolved';
  adminNotes?: string;
}

export interface AssociationSettings {
  associationName: string;
  logoUrl: string;
  contactEmail: string;
  paymentQR: string; // base64
  bankDetails: {
    bankName: string;
    accountNo: string;
    ifscCode: string;
    holderName: string;
  };
}

export interface Database {
  admins: Admin[];
  residents: Resident[];
  notices: Notice[];
  meetings: Meeting[];
  expenses: Expense[];
  payments: MaintenancePayment[];
  dues: MaintenanceDue[];
  finances: FinanceSummary[];
  links: UsefulLink[];
  feedbacks: Feedback[];
  settings: AssociationSettings;
}
